/**
 * Authentication Service - Handles login, register, logout, and auth state
 */

const AuthService = (() => {
  // In-memory user database (in production, this would be on a backend)
  let userDatabase = JSON.parse(localStorage.getItem('user_database')) || [];

  /**
   * Generate JWT-style token (simulated)
   */
  const generateToken = (userId, email) => {
    const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    
    // Token expires in 24 hours
    const expiryTime = Math.floor(Date.now() / 1000) + (24 * 60 * 60);
    const payload = btoa(JSON.stringify({
      userId,
      email,
      iat: Math.floor(Date.now() / 1000),
      exp: expiryTime,
    }));
    
    // Simulated signature
    const signature = btoa('simulated_signature');
    
    return `${header}.${payload}.${signature}`;
  };

  /**
   * Hash password (simple simulation - use proper hashing in production)
   */
  const hashPassword = (password) => {
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return btoa(hash.toString());
  };

  /**
   * Verify password
   */
  const verifyPassword = (password, hash) => {
    return hashPassword(password) === hash;
  };

  /**
   * Register new user
   */
  const register = (email, password, fullName, avatar = null) => {
    try {
      // Validation
      if (!UIService.validateEmail(email)) {
        return { success: false, message: 'Invalid email format' };
      }

      const passwordStrength = UIService.validatePassword(password);
      if (!passwordStrength.isValid) {
        return { success: false, message: UIService.getPasswordStrengthMessage(passwordStrength) };
      }

      if (!fullName || fullName.trim().length < 2) {
        return { success: false, message: 'Name must be at least 2 characters' };
      }

      // Check if user exists
      if (userDatabase.some(u => u.email === email)) {
        return { success: false, message: 'Email already registered' };
      }

      // Create new user
      const newUser = {
        id: Date.now().toString(),
        email,
        password: hashPassword(password),
        fullName,
        avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      userDatabase.push(newUser);
      localStorage.setItem('user_database', JSON.stringify(userDatabase));

      return { success: true, message: 'Registration successful! Please login.' };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, message: 'Registration failed. Please try again.' };
    }
  };

  /**
   * Login user
   */
  const login = (email, password, rememberMe = false) => {
    try {
      if (!UIService.validateEmail(email)) {
        return { success: false, message: 'Invalid email format' };
      }

      // Find user
      const user = userDatabase.find(u => u.email === email);
      if (!user) {
        return { success: false, message: 'User not found' };
      }

      // Verify password
      if (!verifyPassword(password, user.password)) {
        return { success: false, message: 'Incorrect password' };
      }

      // Generate token
      const token = generateToken(user.id, user.email);

      // Prepare user data (without password)
      const userData = {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        avatar: user.avatar,
        createdAt: user.createdAt,
      };

      // Save to localStorage
      StorageService.saveUser(userData);
      StorageService.saveToken(token);
      StorageService.saveLastLogin(new Date().toISOString());

      if (rememberMe) {
        StorageService.saveRememberEmail(email);
      }

      return { success: true, message: 'Login successful', user: userData };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, message: 'Login failed. Please try again.' };
    }
  };

  /**
   * Logout user
   */
  const logout = () => {
    try {
      StorageService.clearAuth();
      return { success: true, message: 'Logout successful' };
    } catch (error) {
      console.error('Logout error:', error);
      return { success: false, message: 'Logout failed' };
    }
  };

  /**
   * Get current user
   */
  const getCurrentUser = () => {
    return StorageService.getUser();
  };

  /**
   * Check if user is authenticated
   */
  const isAuthenticated = () => {
    const user = StorageService.getUser();
    const token = StorageService.getToken();
    return user !== null && token !== null && StorageService.isTokenValid();
  };

  /**
   * Require authentication (redirect if not authenticated)
   */
  const requireAuth = () => {
    if (!isAuthenticated()) {
      window.location.href = 'login.html';
      return false;
    }
    return true;
  };

  /**
   * Update user profile
   */
  const updateProfile = (updates) => {
    try {
      const user = getCurrentUser();
      if (!user) {
        return { success: false, message: 'User not found' };
      }

      // Update in database
      const dbUser = userDatabase.find(u => u.id === user.id);
      if (dbUser) {
        Object.assign(dbUser, updates, { updatedAt: new Date().toISOString() });
        localStorage.setItem('user_database', JSON.stringify(userDatabase));
      }

      // Update in storage
      StorageService.updateUser(updates);

      return { success: true, message: 'Profile updated successfully' };
    } catch (error) {
      console.error('Update profile error:', error);
      return { success: false, message: 'Failed to update profile' };
    }
  };

  /**
   * Initialize demo users (for testing)
   */
  const initializeDemoUsers = () => {
    if (userDatabase.length === 0) {
      userDatabase = [
        {
          id: '1001',
          email: 'demo@example.com',
          password: hashPassword('Demo@123'),
          fullName: 'Demo User',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=demo@example.com',
          createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ];
      localStorage.setItem('user_database', JSON.stringify(userDatabase));
    }
  };

  // Initialize demo users on load
  initializeDemoUsers();

  return {
    register,
    login,
    logout,
    getCurrentUser,
    isAuthenticated,
    requireAuth,
    updateProfile,
    generateToken,
  };
})();
