/**
 * Storage Service - Manages localStorage operations with encryption simulation
 * Handles user data, tokens, and persistent state
 */

const StorageService = (() => {
  const STORAGE_KEYS = {
    USER: 'auth_user',
    TOKEN: 'auth_token',
    LAST_LOGIN: 'auth_last_login',
    REMEMBER_EMAIL: 'remember_email',
  };

  // Simple encryption (base64) - for production use proper encryption
  const encode = (str) => btoa(str);
  const decode = (str) => atob(str);

  return {
    /**
     * Save user data to localStorage
     */
    saveUser: (user) => {
      try {
        localStorage.setItem(STORAGE_KEYS.USER, encode(JSON.stringify(user)));
        return true;
      } catch (error) {
        console.error('Error saving user:', error);
        return false;
      }
    },

    /**
     * Get user data from localStorage
     */
    getUser: () => {
      try {
        const encoded = localStorage.getItem(STORAGE_KEYS.USER);
        return encoded ? JSON.parse(decode(encoded)) : null;
      } catch (error) {
        console.error('Error retrieving user:', error);
        return null;
      }
    },

    /**
     * Save authentication token
     */
    saveToken: (token) => {
      try {
        localStorage.setItem(STORAGE_KEYS.TOKEN, encode(token));
        return true;
      } catch (error) {
        console.error('Error saving token:', error);
        return false;
      }
    },

    /**
     * Get authentication token
     */
    getToken: () => {
      try {
        const encoded = localStorage.getItem(STORAGE_KEYS.TOKEN);
        return encoded ? decode(encoded) : null;
      } catch (error) {
        console.error('Error retrieving token:', error);
        return null;
      }
    },

    /**
     * Check if token is valid (not expired)
     */
    isTokenValid: () => {
      const token = StorageService.getToken();
      if (!token) return false;

      try {
        // Simulate JWT token parsing (header.payload.signature)
        const parts = token.split('.');
        if (parts.length !== 3) return false;

        const payload = JSON.parse(decode(parts[1]));
        const expiryTime = payload.exp * 1000; // Convert to milliseconds
        return Date.now() < expiryTime;
      } catch (error) {
        console.error('Error validating token:', error);
        return false;
      }
    },

    /**
     * Save last login timestamp
     */
    saveLastLogin: (timestamp) => {
      try {
        localStorage.setItem(STORAGE_KEYS.LAST_LOGIN, timestamp.toString());
        return true;
      } catch (error) {
        console.error('Error saving last login:', error);
        return false;
      }
    },

    /**
     * Get last login timestamp
     */
    getLastLogin: () => {
      const timestamp = localStorage.getItem(STORAGE_KEYS.LAST_LOGIN);
      return timestamp ? new Date(parseInt(timestamp)) : null;
    },

    /**
     * Save remember email preference
     */
    saveRememberEmail: (email) => {
      try {
        localStorage.setItem(STORAGE_KEYS.REMEMBER_EMAIL, encode(email));
        return true;
      } catch (error) {
        console.error('Error saving remember email:', error);
        return false;
      }
    },

    /**
     * Get remembered email
     */
    getRememberedEmail: () => {
      try {
        const encoded = localStorage.getItem(STORAGE_KEYS.REMEMBER_EMAIL);
        return encoded ? decode(encoded) : null;
      } catch (error) {
        console.error('Error retrieving remembered email:', error);
        return null;
      }
    },

    /**
     * Update user profile (name, email, avatar)
     */
    updateUser: (updates) => {
      try {
        const user = StorageService.getUser();
        if (!user) return false;
        
        const updated = { ...user, ...updates };
        return StorageService.saveUser(updated);
      } catch (error) {
        console.error('Error updating user:', error);
        return false;
      }
    },

    /**
     * Clear all auth data (logout)
     */
    clearAuth: () => {
      try {
        localStorage.removeItem(STORAGE_KEYS.USER);
        localStorage.removeItem(STORAGE_KEYS.TOKEN);
        localStorage.removeItem(STORAGE_KEYS.LAST_LOGIN);
        return true;
      } catch (error) {
        console.error('Error clearing auth:', error);
        return false;
      }
    },

    /**
     * Get all auth data for debugging
     */
    getAllAuthData: () => {
      return {
        user: StorageService.getUser(),
        token: StorageService.getToken(),
        lastLogin: StorageService.getLastLogin(),
        isAuthenticated: StorageService.getUser() !== null && StorageService.isTokenValid(),
      };
    },
  };
})();
