/**
 * UI Service - Manages UI elements, modals, notifications, and state
 */

const UIService = (() => {
  // Toast notification timeout
  let notificationTimeout = null;

  /**
   * Show notification (toast)
   */
  const showNotification = (message, type = 'info', duration = 3000) => {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.setAttribute('role', 'alert');
    notification.setAttribute('aria-live', 'polite');

    const icon = {
      success: '✓',
      error: '✕',
      warning: '⚠',
      info: 'ℹ',
    }[type] || 'ℹ';

    notification.innerHTML = `
      <span class="notification-icon">${icon}</span>
      <span class="notification-message">${message}</span>
    `;

    document.body.appendChild(notification);

    // Trigger animation
    requestAnimationFrame(() => {
      notification.classList.add('show');
    });

    clearTimeout(notificationTimeout);
    notificationTimeout = setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => notification.remove(), 300);
    }, duration);
  };

  /**
   * Show modal dialog
   */
  const showModal = (title, content, buttons = []) => {
    return new Promise((resolve) => {
      const modal = document.createElement('div');
      modal.className = 'modal';
      modal.setAttribute('role', 'dialog');
      modal.setAttribute('aria-labelledby', 'modal-title');

      let buttonHTML = '';
      buttons.forEach((btn) => {
        buttonHTML += `
          <button class="modal-button modal-button-${btn.type || 'primary'}" data-action="${btn.action}">
            ${btn.label}
          </button>
        `;
      });

      modal.innerHTML = `
        <div class="modal-overlay"></div>
        <div class="modal-content">
          <div class="modal-header">
            <h2 id="modal-title">${title}</h2>
            <button class="modal-close" aria-label="Close modal">&times;</button>
          </div>
          <div class="modal-body">
            ${content}
          </div>
          <div class="modal-footer">
            ${buttonHTML}
          </div>
        </div>
      `;

      document.body.appendChild(modal);

      // Event listeners
      const closeHandler = () => {
        modal.classList.add('closing');
        setTimeout(() => {
          modal.remove();
          resolve(null);
        }, 300);
      };

      modal.querySelector('.modal-close').addEventListener('click', closeHandler);
      modal.querySelector('.modal-overlay').addEventListener('click', closeHandler);

      modal.querySelectorAll('.modal-button').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          const action = e.target.getAttribute('data-action');
          modal.classList.add('closing');
          setTimeout(() => {
            modal.remove();
            resolve(action);
          }, 300);
        });
      });

      requestAnimationFrame(() => {
        modal.classList.add('show');
      });
    });
  };

  /**
   * Show loading overlay
   */
  const showLoading = (message = 'Loading...') => {
    const loader = document.createElement('div');
    loader.id = 'loading-overlay';
    loader.className = 'loading-overlay show';
    loader.innerHTML = `
      <div class="spinner"></div>
      <p>${message}</p>
    `;
    document.body.appendChild(loader);
    return loader;
  };

  /**
   * Hide loading overlay
   */
  const hideLoading = () => {
    const loader = document.getElementById('loading-overlay');
    if (loader) {
      loader.classList.remove('show');
      setTimeout(() => loader.remove(), 300);
    }
  };

  /**
   * Validate email format
   */
  const validateEmail = (email) => {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
  };

  /**
   * Validate password strength
   */
  const validatePassword = (password) => {
    return {
      isValid: password.length >= 8,
      hasUpperCase: /[A-Z]/.test(password),
      hasLowerCase: /[a-z]/.test(password),
      hasNumber: /[0-9]/.test(password),
      hasSpecial: /[!@#$%^&*]/.test(password),
    };
  };

  /**
   * Get password strength message
   */
  const getPasswordStrengthMessage = (strength) => {
    if (!strength.isValid) return 'Password must be at least 8 characters';
    if (!strength.hasUpperCase) return 'Add uppercase letters for stronger password';
    if (!strength.hasLowerCase) return 'Add lowercase letters for stronger password';
    if (!strength.hasNumber) return 'Add numbers for stronger password';
    if (!strength.hasSpecial) return 'Add special characters (!@#$%^&*) for stronger password';
    return 'Strong password';
  };

  /**
   * Format date time
   */
  const formatDateTime = (date) => {
    if (!date) return 'Never';
    const options = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };
    return new Date(date).toLocaleDateString('en-US', options);
  };

  /**
   * Show profile dropdown
   */
  const toggleProfileDropdown = () => {
    const dropdown = document.getElementById('profile-dropdown');
    if (dropdown) {
      dropdown.classList.toggle('active');
    }
  };

  /**
   * Hide profile dropdown
   */
  const hideProfileDropdown = () => {
    const dropdown = document.getElementById('profile-dropdown');
    if (dropdown) {
      dropdown.classList.remove('active');
    }
  };

  /**
   * Animate element
   */
  const animateElement = (element, className, duration = 500) => {
    element.classList.add(className);
    setTimeout(() => {
      element.classList.remove(className);
    }, duration);
  };

  return {
    showNotification,
    showModal,
    showLoading,
    hideLoading,
    validateEmail,
    validatePassword,
    getPasswordStrengthMessage,
    formatDateTime,
    toggleProfileDropdown,
    hideProfileDropdown,
    animateElement,
  };
})();
